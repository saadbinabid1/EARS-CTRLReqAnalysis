function getOutputByInput(input, filePath)

load_system('simulinkModel');
handles=find_system('simulinkModel','FindAll','On','SearchDepth',1,'BlockType','Constant'); 
for i = 1:numel(handles)

    set_param(handles(i), 'Value', num2str(input(i)));
    input_names{i,:} = get_param(handles(i), 'Name'); 
end

handles=find_system('simulinkModel','FindAll','On','SearchDepth',1,'BlockType','Outport'); 
for i = 1:numel(handles)
    output_names{i,:} = get_param(handles(i), 'Name'); 
end

if exist(filePath, 'file') == 2
    fid=fopen(filePath,'a');
else
    fid=fopen(filePath,'w');
    fprintf(fid, 'INPUT: \n');
    fprintf(fid, '%s \n', input_names{:});
    fprintf(fid, 'END INPUT: \n');
    fprintf(fid, 'OUTPUT: \n');
    fprintf(fid, '%s \n', output_names{:});
    fprintf(fid, 'END OUTPUT: \n');
end

[t, x, y] = sim('simulinkModel');

out_text = {};
fprintf(fid, 'START SEQUENCE \n');
output = int8(y);
disp(output)

% out_text{length(out_text)+1} = 'The inputs are: ';
% out_text{length(out_text)+1} = num2str(input);
% out_text{length(out_text)+1} = 'The outputs are: ';
% out_text{length(out_text)+1} = num2str(output);
fprintf(fid, 'The inputs are:  \n');
fprintf(fid, '%s  \n', num2str(input));
fprintf(fid, 'The outputs are:  \n');
fprintf(fid, '%s  \n', num2str(output));
fprintf(fid, 'END SEQUENCE \n');
fclose(fid); 