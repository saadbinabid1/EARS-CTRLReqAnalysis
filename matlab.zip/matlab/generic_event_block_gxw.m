function generic_event_block_gxw(block)

setup(block);

function setup(block)

% Register number of ports
block.NumInputPorts  = 1;
block.NumOutputPorts = 1;

% Setup port properties to be inherited or dynamic
block.SetPreCompInpPortInfoToDynamic;
block.SetPreCompOutPortInfoToDynamic;

% Register parameters
block.NumDialogPrms     = 0;

block.SampleTimes = [0 0];

block.SimStateCompliance = 'DefaultSimState';

block.RegBlockMethod('PostPropagationSetup',    @DoPostPropSetup);
block.RegBlockMethod('InitializeConditions', @InitializeConditions);
block.RegBlockMethod('Start', @Start);
block.RegBlockMethod('Outputs', @Outputs);     % Required
block.RegBlockMethod('Terminate', @Terminate); % Required
%end setup

function DoPostPropSetup(block)
block.NumDworks = 0;


function InitializeConditions(block)

%%
function Start(block)

%end Start

%%
%% Outputs:
%%   Functionality    : Called to generate block outputs in
%%                      simulation step
%%   Required         : Yes
%%   C-MEX counterpart: mdlOutputs
%%
function Outputs(block)

% persistent lock_global;

%block_name = get_param(gcb, 'Name');

% persistent block_memory_struct;

if ~exist('block_memory_struct','var')
    persistent block_memory_struct;
end

lock_value = ' ';
%disp('current block')
%disp(get_param(gcb, 'Name'))
%disp(numel(block_memory_struct))

is_name_found_at_last = false;

for i = 1:2:numel(block_memory_struct)
    if strcmp(block_memory_struct(i).name, get_param(gcb, 'Name'))
        is_name_found_at_last = true;
        disp('matched name for ')
        disp(block_memory_struct(i).name)
        if strcmp(block_memory_struct(i).value, 'true') 
            lock_value = 'true';
        else
            lock_value = 'false';
        end
        break;
    end
end
    
if is_name_found_at_last == false
    block_memory_struct(numel(block_memory_struct) + 1).name = get_param(gcb, 'Name');
    block_memory_struct(numel(block_memory_struct) + 1).value = ' ';
end
    
%disp('value of lock_value is ')
%disp(lock_value)
%disp('----------')
    
%     if isempty(block_memory_struct)
%         block_memory_struct(1).name = get_param(gcb, 'Name');
%         block_memory_struct(1).value = 'init';
%         disp(block_memory_struct(1).value)
%     end

% count = count +1;
% disp('the count is ')
% disp(count)
% get_param(gcb, 'Name')
    

% if block.InputPort(1).Data == true && block.InputPort(2).Data == false
%     lock_value = 'true';
% elseif block.InputPort(2).Data == true
%     lock_value = ' false';
% end
% 
% if block.InputPort(1).Data == true && block.InputPort(2).Data == false
%     block.OutputPort(1).Data = int32(1);
% elseif block.InputPort(2).Data == true
%     block.OutputPort(1).Data = int32(2);
% else
%     if(lock_value == ' ')
%         block.OutputPort(1).Data = int32(2);
%     else
%         if(strcmp(lock_value, 'true'))
%             block.OutputPort(1).Data = int32(1);
%         elseif(strcmp(lock_value, 'false'))
%             block.OutputPort(1).Data = int32(2);
%         end
%     end
% end
% 
if strcmp(lock_value, ' ')
    block.OutputPort(1).Data = false
elseif strcmp(lock_value, 'true')
    block.OutputPort(1).Data = false;
else
    block.OutputPort(1).Data = block.InputPort(1).Data;
end


    

for i = 1:numel(block_memory_struct)
    if strcmp(block_memory_struct(i).name, get_param(gcb, 'Name'))
        if block.InputPort(1).Data == true
            block_memory_struct(i).value = 'true';
        end
        if block.InputPort(1).Data == false
            block_memory_struct(i).value = 'false';
        end
    end
end
         
function Terminate(block)    



